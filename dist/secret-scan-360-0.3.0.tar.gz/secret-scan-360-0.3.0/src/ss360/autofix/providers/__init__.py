# SPDX-License-Identifier: MIT
"""
Provider interfaces for autofix operations.
"""
# namespace package for ss360.autofix.providers