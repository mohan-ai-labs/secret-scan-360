# SPDX-License-Identifier: MIT
"""
Risk scoring module for SS360.
"""
