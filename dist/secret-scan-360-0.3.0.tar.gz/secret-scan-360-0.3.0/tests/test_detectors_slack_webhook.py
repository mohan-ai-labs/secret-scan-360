# Auto-generated smoke test for slack_webhook
import detectors.slack_webhook as m


def test_detector_import():
    assert hasattr(m, "detect")
