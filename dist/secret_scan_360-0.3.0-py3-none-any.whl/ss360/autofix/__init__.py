# SPDX-License-Identifier: MIT
"""
Autofix and rotation framework for SS360.
"""
